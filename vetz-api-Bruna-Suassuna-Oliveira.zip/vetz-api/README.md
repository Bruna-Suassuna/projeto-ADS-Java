# Vetz API
API REST acadêmica para gerenciamento de pets e vacinas.

## Integrantes
- Bruna Suassuna Oliveira — Matrícula: 2515050010

## Tecnologias
Java 17, Spring Boot, Spring Web, Spring Data JPA e H2.

## Executar
```bash
mvn spring-boot:run
```
API: http://localhost:8080

## Endpoints
### Pets
GET /pets
GET /pets/{id}
POST /pets
PUT /pets/{id}
DELETE /pets/{id}

POST/PUT exemplo:
```json
{"nome":"Max","especie":"Cachorro","raca":"Bulldog Francês","dataNascimento":"2022-05-10","peso":12.5,"sexo":"Macho"}
```

### Vacinas
GET /vacinas
GET /vacinas/{id}
POST /vacinas
PUT /vacinas/{id}
DELETE /vacinas/{id}

Crie primeiro um pet. POST/PUT de vacina:
```json
{"nome":"Antirrábica","dataAplicacao":"2026-09-25","proximaDose":"2027-09-25","veterinario":"Dr. Ricardo","pet":{"id":1}}
```

## Banco
H2 Console: http://localhost:8080/h2-console
JDBC URL: jdbc:h2:file:./data/vetzdb
Usuário: sa
Senha: vazia
