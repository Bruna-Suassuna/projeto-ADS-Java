package com.vetz.api;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class VetzApplication { public static void main(String[] args) { SpringApplication.run(VetzApplication.class, args); } }
