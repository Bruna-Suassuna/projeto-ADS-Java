package com.vetz.api.services;
import com.vetz.api.entities.Pet; import com.vetz.api.repositories.PetRepository;
import org.springframework.stereotype.Service; import java.util.*;
@Service
public class PetService {
 private final PetRepository repo; public PetService(PetRepository repo){this.repo=repo;}
 public List<Pet> listarTodos(){return repo.findAll();}
 public Optional<Pet> buscarPorId(Long id){return repo.findById(id);}
 public Pet criar(Pet pet){pet.setId(null); return repo.save(pet);}
 public Optional<Pet> editar(Long id, Pet dados){return repo.findById(id).map(p->{p.setNome(dados.getNome());p.setEspecie(dados.getEspecie());p.setRaca(dados.getRaca());p.setDataNascimento(dados.getDataNascimento());p.setPeso(dados.getPeso());p.setSexo(dados.getSexo());return repo.save(p);});}
 public boolean deletar(Long id){if(!repo.existsById(id)) return false; repo.deleteById(id); return true;}
}
