package com.vetz.api.services;
import com.vetz.api.entities.*; import com.vetz.api.repositories.*;
import org.springframework.stereotype.Service; import java.util.*;
@Service
public class VacinaService {
 private final VacinaRepository repo; private final PetRepository pets;
 public VacinaService(VacinaRepository repo,PetRepository pets){this.repo=repo;this.pets=pets;}
 public List<Vacina> listarTodas(){return repo.findAll();}
 public Optional<Vacina> buscarPorId(Long id){return repo.findById(id);}
 public Optional<Vacina> criar(Vacina v){if(v.getPet()==null||v.getPet().getId()==null)return Optional.empty(); return pets.findById(v.getPet().getId()).map(p->{v.setId(null);v.setPet(p);return repo.save(v);});}
 public Optional<Vacina> editar(Long id, Vacina dados){return repo.findById(id).flatMap(v->{if(dados.getPet()==null||dados.getPet().getId()==null)return Optional.empty();return pets.findById(dados.getPet().getId()).map(p->{v.setNome(dados.getNome());v.setDataAplicacao(dados.getDataAplicacao());v.setProximaDose(dados.getProximaDose());v.setVeterinario(dados.getVeterinario());v.setPet(p);return repo.save(v);});});}
 public boolean deletar(Long id){if(!repo.existsById(id))return false;repo.deleteById(id);return true;}
}
