package com.vetz.api.repositories;
import com.vetz.api.entities.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PetRepository extends JpaRepository<Pet,Long> {}
