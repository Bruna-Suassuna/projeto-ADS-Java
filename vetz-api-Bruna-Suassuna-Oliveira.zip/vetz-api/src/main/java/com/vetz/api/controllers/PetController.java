package com.vetz.api.controllers;
import com.vetz.api.entities.Pet; import com.vetz.api.services.PetService;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/pets") @CrossOrigin(origins="*")
public class PetController {
 private final PetService service; public PetController(PetService service){this.service=service;}
 @GetMapping public List<Pet> getAll(){return service.listarTodos();}
 @GetMapping("/{id}") public ResponseEntity<Pet> getById(@PathVariable Long id){return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @PostMapping public ResponseEntity<Pet> post(@RequestBody Pet pet){return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(pet));}
 @PutMapping("/{id}") public ResponseEntity<Pet> put(@PathVariable Long id,@RequestBody Pet pet){return service.editar(id,pet).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){return service.deletar(id)?ResponseEntity.noContent().build():ResponseEntity.notFound().build();}
}
