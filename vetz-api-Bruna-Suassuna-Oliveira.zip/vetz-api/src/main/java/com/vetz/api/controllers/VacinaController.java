package com.vetz.api.controllers;
import com.vetz.api.entities.Vacina; import com.vetz.api.services.VacinaService;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/vacinas") @CrossOrigin(origins="*")
public class VacinaController {
 private final VacinaService service; public VacinaController(VacinaService service){this.service=service;}
 @GetMapping public List<Vacina> getAll(){return service.listarTodas();}
 @GetMapping("/{id}") public ResponseEntity<Vacina> getById(@PathVariable Long id){return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @PostMapping public ResponseEntity<Vacina> post(@RequestBody Vacina v){return service.criar(v).map(x->ResponseEntity.status(HttpStatus.CREATED).body(x)).orElse(ResponseEntity.badRequest().build());}
 @PutMapping("/{id}") public ResponseEntity<Vacina> put(@PathVariable Long id,@RequestBody Vacina v){return service.editar(id,v).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){return service.deletar(id)?ResponseEntity.noContent().build():ResponseEntity.notFound().build();}
}
