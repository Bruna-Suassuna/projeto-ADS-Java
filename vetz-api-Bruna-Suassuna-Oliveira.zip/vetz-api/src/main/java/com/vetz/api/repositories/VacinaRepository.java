package com.vetz.api.repositories;
import com.vetz.api.entities.Vacina;
import org.springframework.data.jpa.repository.JpaRepository;
public interface VacinaRepository extends JpaRepository<Vacina,Long> {}
