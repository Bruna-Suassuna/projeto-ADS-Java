package com.vetz.api.entities;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name="vacinas")
public class Vacina {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String nome; private LocalDate dataAplicacao; private LocalDate proximaDose; private String veterinario;
 @ManyToOne(optional=false) @JoinColumn(name="pet_id") private Pet pet;
 public Vacina() {}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
 public LocalDate getDataAplicacao(){return dataAplicacao;} public void setDataAplicacao(LocalDate v){this.dataAplicacao=v;}
 public LocalDate getProximaDose(){return proximaDose;} public void setProximaDose(LocalDate v){this.proximaDose=v;}
 public String getVeterinario(){return veterinario;} public void setVeterinario(String v){this.veterinario=v;}
 public Pet getPet(){return pet;} public void setPet(Pet pet){this.pet=pet;}
}
