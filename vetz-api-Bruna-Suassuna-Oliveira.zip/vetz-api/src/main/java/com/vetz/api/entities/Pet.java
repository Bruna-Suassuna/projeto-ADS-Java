package com.vetz.api.entities;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name="pets")
public class Pet {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String nome; private String especie; private String raca; private LocalDate dataNascimento; private Double peso; private String sexo;
 public Pet() {}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
 public String getEspecie(){return especie;} public void setEspecie(String especie){this.especie=especie;}
 public String getRaca(){return raca;} public void setRaca(String raca){this.raca=raca;}
 public LocalDate getDataNascimento(){return dataNascimento;} public void setDataNascimento(LocalDate v){this.dataNascimento=v;}
 public Double getPeso(){return peso;} public void setPeso(Double peso){this.peso=peso;}
 public String getSexo(){return sexo;} public void setSexo(String sexo){this.sexo=sexo;}
}
