import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Pet } from './models/pet';
import { Vacina } from './models/vacina';
import { PetService } from './services/pet.service';
import { VacinaService } from './services/vacina.service';

@Component({ selector: 'app-root', standalone: true, imports: [CommonModule, FormsModule], templateUrl: './app.component.html', styleUrl: './app.component.css' })
export class AppComponent implements OnInit {
  private readonly petsApi = inject(PetService);
  private readonly vacinasApi = inject(VacinaService);
  aba: 'pets' | 'vacinas' = 'pets';
  pets: Pet[] = []; vacinas: Vacina[] = [];
  carregando = false; salvando = false; erro = ''; sucesso = '';
  formulario: 'pet' | 'vacina' | null = null;
  petForm: Pet = this.petVazio(); vacinaForm: Vacina = this.vacinaVazia();
  get petSelecionado(): number | null { return this.vacinaForm.pet?.id ?? null; }
  set petSelecionado(id: number | null) { this.vacinaForm.pet = { ...this.petVazio(), id: id ?? undefined }; }
  ngOnInit(): void { this.recarregar(); }
  petVazio(): Pet { return { nome: '', especie: '', raca: '', dataNascimento: null, peso: null, sexo: '' }; }
  vacinaVazia(): Vacina { return { nome: '', dataAplicacao: null, proximaDose: null, veterinario: '', pet: this.petVazio() }; }
  selecionarAba(aba: 'pets' | 'vacinas'): void { this.aba = aba; this.formulario = null; this.erro = ''; this.sucesso = ''; this.recarregar(); }
  recarregar(): void {
    this.carregando = true; this.erro = '';
    this.petsApi.getAll().subscribe({ next: pets => { this.pets = pets; this.vacinasApi.getAll().subscribe({ next: vacinas => { this.vacinas = vacinas; this.carregando = false; }, error: e => this.falha(e) }); }, error: e => this.falha(e) });
  }
  abrirPet(pet?: Pet): void { this.petForm = pet ? { ...pet } : this.petVazio(); this.formulario = 'pet'; this.erro = ''; this.sucesso = ''; }
  abrirVacina(vacina?: Vacina): void { this.vacinaForm = vacina ? { ...vacina, pet: { ...vacina.pet } } : this.vacinaVazia(); this.formulario = 'vacina'; this.erro = ''; this.sucesso = ''; }
  fechar(): void { this.formulario = null; }
  salvarPet(): void {
    if (!this.petForm.nome.trim() || !this.petForm.especie.trim()) { this.erro = 'Preencha nome e espécie.'; return; }
    this.salvando = true; this.erro = '';
    const id = this.petForm.id;
    const req = id ? this.petsApi.update(id, this.petForm) : this.petsApi.create(this.petForm);
    req.subscribe({ next: () => { this.salvando = false; this.formulario = null; this.sucesso = id ? 'Pet atualizado!' : 'Pet cadastrado!'; this.recarregar(); }, error: e => this.falha(e) });
  }
  salvarVacina(): void {
    if (!this.vacinaForm.nome.trim() || !this.vacinaForm.pet?.id) { this.erro = 'Informe o nome da vacina e selecione um pet.'; return; }
    this.salvando = true; this.erro = '';
    const id = this.vacinaForm.id;
    const req = id ? this.vacinasApi.update(id, this.vacinaForm) : this.vacinasApi.create(this.vacinaForm);
    req.subscribe({ next: () => { this.salvando = false; this.formulario = null; this.sucesso = id ? 'Vacina atualizada!' : 'Vacina cadastrada!'; this.recarregar(); }, error: e => this.falha(e) });
  }
  excluirPet(pet: Pet): void {
    if (!pet.id || !confirm(`Excluir ${pet.nome}? Se houver vacinas vinculadas, exclua-as primeiro.`)) return;
    this.petsApi.delete(pet.id).subscribe({ next: () => { this.sucesso = 'Pet excluído!'; this.recarregar(); }, error: e => this.falha(e) });
  }
  excluirVacina(vacina: Vacina): void {
    if (!vacina.id || !confirm(`Excluir a vacina ${vacina.nome}?`)) return;
    this.vacinasApi.delete(vacina.id).subscribe({ next: () => { this.sucesso = 'Vacina excluída!'; this.recarregar(); }, error: e => this.falha(e) });
  }
  nomePet(vacina: Vacina): string { return vacina.pet?.nome ?? 'Pet não identificado'; }
  private falha(e: HttpErrorResponse): void { this.carregando = false; this.salvando = false; this.erro = e.status === 0 ? 'Não foi possível conectar à API. Inicie o Spring Boot em http://localhost:8080.' : `Erro ${e.status}: não foi possível concluir a operação. Confira os dados e o servidor.`; }
}
