import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pet } from '../models/pet';
@Injectable({ providedIn: 'root' })
export class PetService {
  private readonly http = inject(HttpClient);
  private readonly url = 'http://localhost:8080/pets';
  getAll(): Observable<Pet[]> { return this.http.get<Pet[]>(this.url); }
  getById(id: number): Observable<Pet> { return this.http.get<Pet>(`${this.url}/${id}`); }
  create(pet: Pet): Observable<Pet> { return this.http.post<Pet>(this.url, pet); }
  update(id: number, pet: Pet): Observable<Pet> { return this.http.put<Pet>(`${this.url}/${id}`, pet); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}
