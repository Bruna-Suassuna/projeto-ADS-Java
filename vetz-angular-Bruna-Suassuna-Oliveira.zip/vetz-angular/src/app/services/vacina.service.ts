import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vacina } from '../models/vacina';
@Injectable({ providedIn: 'root' })
export class VacinaService {
  private readonly http = inject(HttpClient);
  private readonly url = 'http://localhost:8080/vacinas';
  getAll(): Observable<Vacina[]> { return this.http.get<Vacina[]>(this.url); }
  getById(id: number): Observable<Vacina> { return this.http.get<Vacina>(`${this.url}/${id}`); }
  create(vacina: Vacina): Observable<Vacina> { return this.http.post<Vacina>(this.url, vacina); }
  update(id: number, vacina: Vacina): Observable<Vacina> { return this.http.put<Vacina>(`${this.url}/${id}`, vacina); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}
