import { Pet } from './pet';
export interface Vacina { id?: number; nome: string; dataAplicacao: string | null; proximaDose: string | null; veterinario: string; pet: Pet; }
