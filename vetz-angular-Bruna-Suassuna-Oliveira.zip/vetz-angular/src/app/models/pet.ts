export interface Pet { id?: number; nome: string; especie: string; raca: string; dataNascimento: string | null; peso: number | null; sexo: string; }
