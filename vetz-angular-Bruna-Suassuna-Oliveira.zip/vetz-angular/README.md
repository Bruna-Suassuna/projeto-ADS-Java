# Vetz — Front-end Angular (Fase 2)

**Aluna:** Bruna Suassuna Oliveira  
**Matrícula:** 2515050010

Aplicação Angular para gerenciar **Pets** e **Vacinas**, consumindo a API REST Java da Fase 1.

## Requisitos

- Node.js 20 ou 22 e npm
- Java 17 e Maven para executar a API da Fase 1

## Como executar

1. Inicie a API Java da Fase 1 na porta **8080** (na pasta `vetz-api`, execute `mvn spring-boot:run`).
2. Abra um terminal nesta pasta `vetz-angular`.
3. Execute `npm install` e depois `npm start`.
4. Acesse `http://localhost:4200`.

> O front usa `http://localhost:8080/pets` e `http://localhost:8080/vacinas`. A API Java entregue anteriormente já possui `@CrossOrigin(origins="*")` nos controllers. Se a API estiver em outra porta, altere as URLs em `src/app/services/`.

## Métodos implementados (para ambas as entidades)

| Ação | Pets | Vacinas |
|---|---|---|
| GET ALL | `GET /pets` | `GET /vacinas` |
| GET BY ID (extra) | `GET /pets/{id}` | `GET /vacinas/{id}` |
| POST | `POST /pets` | `POST /vacinas` |
| PUT | `PUT /pets/{id}` | `PUT /vacinas/{id}` |
| DELETE | `DELETE /pets/{id}` | `DELETE /vacinas/{id}` |

Os formulários realizam POST e PUT; os botões Excluir realizam DELETE; a listagem é atualizada com GET. Vacinas exigem selecionar um pet previamente cadastrado. Como a API possui relacionamento entre Pet e Vacina, exclua as vacinas vinculadas antes de excluir um pet.

## Estrutura

- `src/app/models`: interfaces TypeScript alinhadas às entidades Java.
- `src/app/services`: chamadas HTTP com `HttpClient`.
- `src/app/app.component.ts`: lógica das telas, formulários e operações.
- `src/app/app.component.html`: interface de pets e vacinas.
- `src/app/app.component.css`: identidade visual do Vetz e responsividade.

**Observação:** o banco H2 da API da Fase 1 é configurado em memória. Os dados podem desaparecer quando o backend for reiniciado.
